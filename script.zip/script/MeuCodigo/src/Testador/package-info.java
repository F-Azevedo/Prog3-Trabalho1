/**
 * Pacote para organizar a main, deixando ela separada dos outros pacotes.<br>
 */
package Testador;