/**
 * Pacote para gerenciar as saídas do programa.<br>
 * <ul>
 *     <li>Possui funções para imprimir os 10 relatórios formatados conforme especificação.</li>
 * </ul>
 */
package Saida;