/**
 * Pacote para gerenciar processos da eleição.<br>
 *  <ul>
 *      <li>Criar nova eleição, novo partido, novo candidato.</li>
 *      <li>Ordenar partido.</li>
 *  </ul>
 */
package Eleicoes;