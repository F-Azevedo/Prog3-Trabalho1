/**
 * Pacote para gerenciar e tratar a leitura das entradas do programa.
 */
package Entrada;